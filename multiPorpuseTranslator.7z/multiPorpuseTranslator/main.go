package main

import (
	"bufio"
	"fmt"
	"multiPorpuseTranslator/convertir"
	"os"
)


func main () {
	//scaneando la cadena
	scanner := bufio.NewReader(os.Stdin)
	fmt.Println("Translador de String")
	fmt.Println("Ingrese la cadena que quiere convertir:")
	//declarando variable para convertir
	textoATraducir, _ := scanner.ReadString('\n')
	//imprimiendo variables
	fmt.Print(textoATraducir)
	//conver a string

	cadena:=convertir.StringToBin(textoATraducir)
	fmt.Println(cadena)

}


