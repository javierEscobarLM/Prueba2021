package convertir

import (
	"fmt"
)
type formatoOrigen string

func StringToBin(s string) (formatoOrigen string) {
	//valores := strings.Split(s,"cadena")
	for i, c := range s {
		if i!=0{
			formatoOrigen+=" "
		}
		formatoOrigen = fmt.Sprintf("%s%b",formatoOrigen, c)
	}
	return
}