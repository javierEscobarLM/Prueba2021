package convertir

import (
	"encoding/base64"
	"fmt"
	"log"
)

type MorseChar string

func (mc MorseChar) Decode() []byte {
	if r, ok := morseCode2Littera[mc]; ok {
		return []byte{r}
	}
	return []byte(mc)
}

var morseCode2Littera = map[MorseChar]byte{
	".-":   'A',
	"-...": 'B',
	"-.-.": 'C',
	"-..":  'D',
	".":    'E',
	"..-.": 'F',
	"--.":  'G',
	"....": 'H',
	"..":   'I',
	".---": 'J',
	"-.-":  'K',
	".-..": 'L',
	"--":   'M',
	"-.":   'N',
	"---":  'O',
	".--.": 'P',
	"--.-": 'Q',
	".-.":  'R',
	"...":  'S',
	"-":    'T',
	"..-":  'U',
	"...-": 'V',
	".--":  'W',
	"-..-": 'X',
	"-.--": 'Y',
	"--..": 'Z',
}
var edata = "MzkzMzUzNTM5NTMzMzk1Mzc5OTUzNzMzMzM1MzUzOTM1Mw=="
func stringToMorse(){

	// Convert from base64
	sdata, err := base64.StdEncoding.DecodeString(edata)
	if err != nil {
		log.Fatal(err)
	}

	code := make([]byte, 0, 4)

	var morseCode []byte
	var decodedMsg []byte

	for _, c := range sdata {

		switch c {
		case '3':
			code = append(code, '.')
			continue
		case '9':
			code = append(code, '-')
			continue
		case '7':
			mc := MorseChar(code)
			morseCode = append(morseCode, []byte(mc)...)
			morseCode = append(morseCode, []byte("   ")...)
			decodedMsg = append(decodedMsg, mc.Decode()...)
			decodedMsg = append(decodedMsg, ' ')
		case '5':
			mc := MorseChar(code)
			morseCode = append(morseCode, []byte(mc)...)
			morseCode = append(morseCode, ' ')
			decodedMsg = append(decodedMsg, mc.Decode()...)
		}

		code = code[:0]
	}

	// Print final letter
	if len(code) > 0 {
		mc := MorseChar(code)
		morseCode = append(morseCode, []byte(mc)...)
		decodedMsg = append(decodedMsg, mc.Decode()...)
	}

	// Final output
	fmt.Println(string(morseCode))
	fmt.Println(string(decodedMsg))
}

